package org.example.testng.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.pom.DemoqaForm;
import org.example.utils.SeleniumDriver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FormTest {

    private static final Logger logger = LogManager.getLogger(FormTest.class);


    public static WebDriver driver;
    public static String URI = "https://demoqa.com/automation-practice-form/";
    public static String FIRST_NAME = "Cristian";
    public static String LAST_NAME = "Dragan";
    public static String EMAIL = "example@gmail.com";
    public static String GENDER = "Male";
    public static String MOBILE = "1234567890";
    public static String DATE_OF_BIRTH = "10 Aug 2007";
    public static String HOBBY = "Sports, Music";
    public static String ADDRESS = "Chisinau";
    public static String STATE = "Rajasthan";
    public static String CITY = "Jaipur";

    @BeforeTest
    public void beforeTest() {
        driver = SeleniumDriver.getAutoLocalDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void formTest() {
        logger.info("Start Test");

        driver.get(URI);
        DemoqaForm form = new DemoqaForm(driver);
        form.setFirstName(FIRST_NAME);
        form.setLastName(LAST_NAME);
        form.setEmail(EMAIL);
        form.setGender(GENDER);
        form.setMobile(MOBILE);
        form.setDateOfBirth(DATE_OF_BIRTH);
        form.setHobby(HOBBY);
        form.setAddress(ADDRESS);
        form.setState(STATE);
        form.setCity(CITY);
        logger.info("Stop Test");
    }

    @AfterTest
    public void afterTest() {
        driver.quit();
    }
}