package org.example.pom;

import io.qameta.allure.Allure;
import io.qameta.allure.AttachmentOptions;
import io.qameta.allure.Step;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.ByteArrayInputStream;

public class DemoqaForm {

    public static WebDriver driver;

    @FindBy(xpath = "//*[@id='firstName']")
    WebElement firstName;

    @FindBy(css = "#lastName")
    WebElement lastName;

    @FindBy(id = "userEmail")
    WebElement userEmail;

    @FindBy(id = "userNumber")
    WebElement userNumber;

    @FindBy(id = "dateOfBirthInput")
    WebElement dateOfBirth;

    @FindBy(id = "currentAddress")
    WebElement currentAddress;

    public DemoqaForm(WebDriver driverParam) {
        driver = driverParam;
        PageFactory.initElements(driverParam, this);
    }

    @Step("Set first name(firstNameParam)")
    public void setFirstName(String firstNameParam) {
        firstName.clear();
        firstName.sendKeys(firstNameParam);
    }

    public void setLastName(String lastNameParam) {
        lastName.clear();
        lastName.sendKeys(lastNameParam);
    }


    public void setEmail(String emailParam) {
        userEmail.clear();
        userEmail.sendKeys(emailParam);
    }

    public void setGender(String genderParam) {
        WebElement gender = driver.findElement(By.xpath("//*[@id='genterWrapper']//label[text()='" + genderParam + "']"));
        gender.click();
    }

    public void setMobile(String mobileParam) {
        userNumber.clear();
        userNumber.sendKeys(mobileParam);
    }

    public void setDateOfBirth(String dateParam) {
        dateOfBirth.sendKeys(Keys.chord(Keys.CONTROL, "a"), dateParam);
        dateOfBirth.sendKeys(Keys.ENTER);
    }

    public void setHobby(String hobbiesParam) {
        for (String hobbyName : hobbiesParam.split(",")) {
            WebElement hobby = driver.findElement(By.xpath("//*[@id='hobbiesWrapper']//label[text()='" + hobbyName.trim() + "']"));
            hobby.click();
        }
    }
    public void setAddress(String addressParam) {
        currentAddress.clear();
        currentAddress.sendKeys(addressParam);
    }

    public void setState(String stateParam) {
        WebElement state = driver.findElement(By.xpath("//*[@id='state']//input"));
        state.sendKeys(stateParam);
        state.sendKeys(Keys.ENTER);
    }

    public void setCity(String cityParam) {
        WebElement city = driver.findElement(By.xpath("//*[@id='city']//input"));
        city.sendKeys(cityParam);
        city.sendKeys(Keys.ENTER);
    }

    protected void takeScreenshot(String stepName) {
        try {
            byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            Allure.attachment(stepName, "image/png", new ByteArrayInputStream(screenshot), AttachmentOptions.withFileExtension(".png"));
        } catch (Exception e) {
            Allure.attachment("Screenshot Error", e.toString());
        }
    }


}